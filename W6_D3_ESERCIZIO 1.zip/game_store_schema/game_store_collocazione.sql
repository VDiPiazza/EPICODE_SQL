-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: game_store
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `collocazione`
--

DROP TABLE IF EXISTS `collocazione`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `collocazione` (
  `IDcollocazione` int NOT NULL AUTO_INCREMENT,
  `id_store` int NOT NULL,
  `idgame` int NOT NULL,
  PRIMARY KEY (`IDcollocazione`),
  KEY `store_idx` (`id_store`),
  KEY `game_idx` (`idgame`),
  CONSTRAINT `game` FOREIGN KEY (`idgame`) REFERENCES `videogames` (`idgame`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `store` FOREIGN KEY (`id_store`) REFERENCES `negozi` (`id_store`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='COLLOCAZIONE VIDEOGIOCO:\nCreate questa relazione utilizzando i dati estratti dalle tabelle precedenti.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collocazione`
--

LOCK TABLES `collocazione` WRITE;
/*!40000 ALTER TABLE `collocazione` DISABLE KEYS */;
INSERT INTO `collocazione` VALUES (28,2,1),(29,1,1),(30,1,2),(31,1,3),(32,1,4),(33,1,6),(34,2,3),(35,2,4),(36,2,5),(37,2,6),(38,3,5),(39,3,6),(40,3,7),(41,3,8),(42,7,1),(43,7,2),(44,7,3),(45,7,4),(46,7,8),(47,8,8),(48,8,7),(49,8,6),(50,8,5),(51,9,4),(52,9,3),(53,9,2),(54,9,1);
/*!40000 ALTER TABLE `collocazione` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-08 21:04:48
