-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: game_store
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `servizio_impiegati`
--

DROP TABLE IF EXISTS `servizio_impiegati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servizio_impiegati` (
  `idcarica` int NOT NULL AUTO_INCREMENT,
  `CodiceFiscale` varchar(25) NOT NULL,
  `CodiceStore` varchar(25) NOT NULL,
  `DataInizio` varchar(25) NOT NULL,
  `DataFine` varchar(25) NOT NULL,
  `Carica` varchar(25) NOT NULL,
  `IdImpiegato` int NOT NULL,
  PRIMARY KEY (`idcarica`),
  KEY `servizi_impiegati_idx` (`IdImpiegato`),
  CONSTRAINT `servizi_impiegati` FOREIGN KEY (`IdImpiegato`) REFERENCES `impiegati` (`IdImpiegato`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servizio_impiegati`
--

LOCK TABLES `servizio_impiegati` WRITE;
/*!40000 ALTER TABLE `servizio_impiegati` DISABLE KEYS */;
INSERT INTO `servizio_impiegati` VALUES (21,'	ABC12345XYZ67890	','	1	','	2023-01-01	','	2023-12-31	','	Cassiere	',1),(22,'	DEF67890XYZ12345	','	2	','	2023-02-01	','	2023-11-30	','	Commesso	',2),(23,'	GHI12345XYZ67890	','	3	','	2023-03-01	','	2023-10-31	','	Magazziniere	',3),(24,'	JKL67890XYZ12345	','	4	','	2023-04-01	','	2023-09-30	','	Addetto alle vendite	',4),(25,'	MNO12345XYZ67890	','	5	','	2023-05-01	','	2023-08-31	','	Addetto alle pulizie	',4),(26,'	PQR67890XYZ12345	','	6	','	2023-06-01	','	2023-07-31	','	Commesso	',6),(27,'	STU12345XYZ67890	','	7	','	2023-07-01	','	2023-06-30	','	Commesso	',7),(28,'	VWX67890XYZ12345	','	8	','	2023-08-01	','	2023-05-31	','	Cassiere	',8),(29,'	YZA12345XYZ67890	','	9	','	2023-09-01	','	2023-04-30	','	Cassiere	',9),(30,'	BCD67890XYZ12345	','	10	','	2023-10-01	','	2023-03-31	','	Cassiere	',10);
/*!40000 ALTER TABLE `servizio_impiegati` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-08 21:04:48
