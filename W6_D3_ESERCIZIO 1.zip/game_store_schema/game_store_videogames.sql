-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: game_store
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `videogames`
--

DROP TABLE IF EXISTS `videogames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videogames` (
  `idgame` int NOT NULL AUTO_INCREMENT,
  `Titolo` varchar(45) NOT NULL,
  `Sviluppatore` varchar(25) NOT NULL,
  `AnnoDistribuzione` varchar(25) NOT NULL,
  `Prezzo` decimal(10,2) NOT NULL,
  `Genere` varchar(25) NOT NULL,
  `RemakeDi` tinyint DEFAULT NULL,
  PRIMARY KEY (`idgame`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `videogames`
--

LOCK TABLES `videogames` WRITE;
/*!40000 ALTER TABLE `videogames` DISABLE KEYS */;
INSERT INTO `videogames` VALUES (1,'	Fifa 2023	','	EA Sports	','	15/07/1905	',49.99,'	Calcio	',NULL),(2,'	Assassin\'s Creed: Valhalla	','	Ubisoft	','	12/07/1905	',59.99,'	Action	',NULL),(3,'	Super Mario Odyssey	','	Nintendo	','	09/07/1905	',39.99,'	Platform	',NULL),(4,'	The Last of Us Part II	','	Naughty Dog	','	12/07/1905	',69.99,'	Action	',NULL),(5,'	Cyberpunk 2077	','	CD Projekt Red	','	12/07/1905	',49.99,'	RPG	',NULL),(6,'	Animal Crossing: New Horizons	','	Nintendo	','	12/07/1905	',54.99,'	Simulation	',NULL),(7,'	Call of Duty: Warzone	','	Infinity Ward	','	12/07/1905	',0.00,'	FPS	',NULL),(8,'	The Legend of Zelda: Breath of the Wild	','	Nintendo	','	09/07/1905	',59.99,'	Action-Adventure	',NULL),(9,'	Fortnite	','	Epic Games	','	09/07/1905	',0.00,'	Battle Royale	',NULL),(10,'	Red Dead Redemption 2	','	Rockstar Games	','	10/07/1905	',39.99,'	Action-Adventure	',NULL);
/*!40000 ALTER TABLE `videogames` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-08 21:04:47
