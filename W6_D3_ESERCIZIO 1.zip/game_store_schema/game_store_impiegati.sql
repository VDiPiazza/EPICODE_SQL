-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: game_store
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `impiegati`
--

DROP TABLE IF EXISTS `impiegati`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `impiegati` (
  `CodiceFiscale` varchar(45) NOT NULL,
  `Nome` varchar(25) NOT NULL,
  `TitoloStudio` varchar(25) NOT NULL,
  `Recapito` varchar(25) NOT NULL,
  `IdImpiegato` int NOT NULL AUTO_INCREMENT,
  `id_store` int NOT NULL,
  PRIMARY KEY (`IdImpiegato`),
  KEY `impiegati_negozio_idx` (`id_store`),
  CONSTRAINT `impiegati_negozio` FOREIGN KEY (`id_store`) REFERENCES `negozi` (`id_store`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `impiegati`
--

LOCK TABLES `impiegati` WRITE;
/*!40000 ALTER TABLE `impiegati` DISABLE KEYS */;
INSERT INTO `impiegati` VALUES ('	ABC12345XYZ67890	','	Mario Rossi	','	Laurea in Economia	','	mario.rossi@email.com	',1,1),('	DEF67890XYZ12345	','	Anna Verdi	','	Diploma di Ragioneria	','	anna.verdi@email.com	',2,2),('	GHI12345XYZ67890	','	Luigi Bianchi	','	Laurea in Informatica	','	luigi.bianchi@email.com	',3,3),('	JKL67890XYZ12345	','	Laura Neri	','	Laurea in Lingue	','	laura.neri@email.com	',4,3),('	MNO12345XYZ67890	','	Andrea Moretti	','	Diploma di Geometra	','	andrea.moretti@email.com',5,7),('	PQR67890XYZ12345	','	Giulia Ferrara	','	Laurea in Psicologia	','	giulia.ferrara@email.com',6,8),('	STU12345XYZ67890	','	Marco Esposito	','	Diploma di Elettronica	','	marco.esposito@email.com',7,7),('	VWX67890XYZ12345	','	Sara Romano	','	Laurea in Giurisprudenza','	sara.romano@email.com	',8,8),('	YZA12345XYZ67890	','	Roberto De Luca	','	Diploma di Informatica	','	roberto.deluca@email.com',9,9),('	BCD67890XYZ12345	','	Elena Santoro	','	Laurea in Lettere	','	elena.santoro@email.com	',10,10);
/*!40000 ALTER TABLE `impiegati` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-08 21:04:47
