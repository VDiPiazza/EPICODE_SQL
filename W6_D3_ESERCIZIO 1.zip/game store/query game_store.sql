-- la query serve per sapere il negozio in cui lavora o ha lavorato l'impiegato e quale carica ha ricoperto
SELECT 
    a.nome, a.citta, b.nome, b.codicefiscale, c.carica, c.DataInizio, c.DataFine
FROM
    negozi AS a
        JOIN
    impiegati AS b ON a.id_store = b.id_store
        JOIN
    servizio_impiegati AS c ON b.IdImpiegato = c.idimpiegato




-- la query permette di consultare l'elenco dei negozi e i giochi che questi vendono, mostrando il prezzo per ogni titolo
SELECT 
    a.nome, a.citta, b.titolo, b.prezzo
FROM
    negozi AS a
        JOIN
    collocazione AS c ON a.id_store = c.id_store
        JOIN
    videogames AS b ON b.idgame = c.idgame
