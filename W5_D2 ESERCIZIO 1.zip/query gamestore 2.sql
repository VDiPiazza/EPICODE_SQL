SELECT 
    a.titolo,
    a.prezzo,
    a.copie,
    a.remake,
    b.nome,
    c.settore,
    d.scaffale
FROM
    videogiochi AS a
        JOIN
    negozi AS b ON a.negozio = b.id_store
        JOIN
    settori AS c ON a.settore = c.id_sett
        JOIN
    scaffali AS d ON a.scaffale = d.id_spot
WHERE
    remake = '0' AND d.scaffale = 'alto'