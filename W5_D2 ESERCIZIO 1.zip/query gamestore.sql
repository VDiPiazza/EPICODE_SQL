SELECT 
    a.cf, a.nome, a.ruolo, b.nome, b.citta, a.data
FROM
    negozi AS b
        JOIN
    impiegati AS a ON a.id_store = b.id_store
WHERE
    a.ruolo = 'commesso'
        AND b.citta = 'agrigento'
ORDER BY a.nome ASC