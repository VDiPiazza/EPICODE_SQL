SELECT 
    a.utente, b.nome, c.titolo, a.prestato_il, a.ritardo
FROM
    prestiti AS a
        JOIN
    utenti AS b ON a.utente = b.cf
        JOIN
    libri AS c ON a.libro = c.isbn
WHERE
    a.ritardo = '1'
ORDER BY a.prestato_il ASC